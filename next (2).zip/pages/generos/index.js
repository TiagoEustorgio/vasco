import Pagina from '@/Components/Pagina'
import apiAnime from '@/services/apiAnime';
import React from 'react'
import axios from 'axios';

const index = ({ anime, generos}) => {
  return (
    <Pagina titulo="Genêros">
      {generos.map(item =>
        <ul key={item.mal_id}>
          <li>{item.name}({item.count})</li>
        </ul>)}
    </Pagina>
  )
}
export default index

export async function getServerSideProps(context){
    const resultado = await apiAnime.get('/genres/anime')
    const generos = resultado.data.data
    return {
        props: {generos}
    }
  }