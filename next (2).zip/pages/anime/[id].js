import Pagina from '@/Components/Pagina'
import React from 'react'
import apiAnime from '@/services/apiAnime';

Detalhes = ({anime}) => {
  return (
    <Pagina titulo={anime.title}>


    </Pagina>
  )
}

export default Detalhes
