import Pagina from '@/Components/Pagina'
import apiAnime from '@/services/apiAnime';
import React from 'react'
import { Col, Row, Table } from 'react-bootstrap'
import { AiFillAndroid } from "react-icons/ai";
import axios from 'axios'
const index = ({anime}) => {
  return (
    <Pagina titulo="Anime">
        <Row>
        <Col md={12}>
        <Table striped bordered hover>
        <thead>
        <tr>
            <th>Detalhes</th>
            <th>Titulo</th>
            <th>Duração</th>
            <th>Ano</th>
        </tr>
        </thead>
        <tbody>
        
        {anime.map(item => (
        <tr key={item.mal_id}>


          <td><a href={'/anime/' + item.mal_id}><AiFillAndroid/></a></td>
          <td>{item.title}</td>
          <td>{item.duration}</td>
          <td>{item.year}</td>
        </tr>
        ))}
        
        </tbody>
        </Table>
        </Col>
        </Row>
    </Pagina>
  )

}
export default index

export async function getServerSideProps(context){
    

    const resultado = await apiAnime.get('/anime')
    const anime = resultado.data.data

    return {

        props: {anime}
    }
}